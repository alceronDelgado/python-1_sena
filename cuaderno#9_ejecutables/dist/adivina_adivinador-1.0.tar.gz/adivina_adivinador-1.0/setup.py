from setuptools import setup

setup(
    #Nombre del paquete
    name="adivina_adivinador",
    version="1.0",
    description="paquete que contiene las funciones para retornar el valor aleatorio de la computadora",
    author="Alejandro ceron delgado",
    url="http://www.mipagina.com",
    #Podemos guardarlo en formato de lista si tenemos que hacerlo con más paquetes.
    packages=['package']
)